export type Language = 'en' | 'hi' | 'te';

export interface PlanCategory {
  id: string;
  name: string;
  description: string;
  image: string;
}

export interface BudgetItem {
  id: string;
  name: string;
  amount: number;
  category: 'material' | 'labor' | 'other';
}

export interface User {
  uid: string;
  email: string | null;
  phoneNumber: string | null;
  displayName: string | null;
}
