import React from 'react';
import { motion } from 'motion/react';
import { Home, PenTool, Calculator, MessageSquare, LogOut, Globe } from 'lucide-react';
import { Language } from '../types';
import VoiceInput from './VoiceInput';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  onLogout: () => void;
  onVoiceTranscript?: (text: string) => void;
}

export default function Layout({ children, activeTab, setActiveTab, language, setLanguage, onLogout, onVoiceTranscript }: LayoutProps) {
  const tabs = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'sketch', label: 'Sketch', icon: PenTool },
    { id: 'budget', label: 'Budget', icon: Calculator },
    { id: 'chat', label: 'AI Planning', icon: MessageSquare },
  ];

  const languages: { id: Language; label: string }[] = [
    { id: 'en', label: 'English' },
    { id: 'hi', label: 'हिन्दी' },
    { id: 'te', label: 'తెలుగు' },
  ];

  return (
    <div className="min-h-screen bg-[#FDF5E6] text-[#4A3728] font-sans relative overflow-hidden">
      {/* Background with blurry construction image */}
      <div 
        className="fixed inset-0 z-0 opacity-10"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1503387762-592dee58c460?auto=format&fit=crop&q=80&w=1920&blur=10")',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />

      {/* Navigation Sidebar */}
      <nav className="fixed left-0 top-0 h-full w-20 md:w-64 bg-white/80 backdrop-blur-md border-r border-[#D2B48C] z-50 flex flex-col shadow-xl">
        <div className="p-6 flex items-center gap-3">
          <div className="w-10 h-10 bg-[#8B4513] rounded-lg flex items-center justify-center shadow-lg">
            <Home className="text-white" size={24} />
          </div>
          <span className="hidden md:block font-bold text-xl tracking-tight text-[#8B4513]">VastuPlan AI</span>
        </div>

        <div className="flex-1 px-4 py-8 space-y-2">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full flex items-center gap-4 p-3 rounded-xl transition-all duration-300 ${
                activeTab === tab.id
                  ? 'bg-[#8B4513] text-white shadow-lg scale-105'
                  : 'hover:bg-[#F5DEB3] text-[#5D4037]'
              }`}
            >
              <tab.icon size={24} />
              <span className="hidden md:block font-medium">{tab.label}</span>
            </button>
          ))}
        </div>

        <div className="p-4 border-t border-[#D2B48C] space-y-4">
          <div className="flex items-center gap-2 px-2">
            <Globe size={20} className="text-[#8B4513]" />
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value as Language)}
              className="bg-transparent border-none focus:ring-0 text-sm font-medium cursor-pointer hidden md:block"
            >
              {languages.map((lang) => (
                <option key={lang.id} value={lang.id}>{lang.label}</option>
              ))}
            </select>
          </div>

          <button
            onClick={onLogout}
            className="w-full flex items-center gap-4 p-3 rounded-xl hover:bg-red-50 text-red-600 transition-all duration-300"
          >
            <LogOut size={24} />
            <span className="hidden md:block font-medium">Logout</span>
          </button>
        </div>
      </nav>

      {/* Main Content */}
      <main className="ml-20 md:ml-64 p-4 md:p-8 relative z-10">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.4, ease: "easeOut" }}
          className="max-w-7xl mx-auto"
        >
          {children}
        </motion.div>
      </main>

      {/* Floating Mic Option */}
      {onVoiceTranscript && <VoiceInput onTranscript={onVoiceTranscript} />}
    </div>
  );
}
