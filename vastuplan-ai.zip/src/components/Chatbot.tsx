import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Bot, User, Sparkles, Loader2, Mic, Volume2 } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import ReactMarkdown from 'react-markdown';

const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export default function Chatbot({ voiceTranscript }: { voiceTranscript?: string }) {
  const [messages, setMessages] = useState<{ role: 'user' | 'bot', text: string }[]>([
    { role: 'bot', text: 'Namaste! I am your VastuPlan AI assistant. How can I help you plan your construction today? I can suggest materials, color combinations, and interior/exterior designs.' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (voiceTranscript) {
      setInput(voiceTranscript);
    }
  }, [voiceTranscript]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setLoading(true);

    try {
      const model = "gemini-3-flash-preview";
      const response = await genAI.models.generateContent({
        model,
        contents: [
          {
            role: 'user',
            parts: [{ text: `You are VastuPlan AI, an expert construction planner and architect with deep knowledge of Indian construction practices, Vastu Shastra, modern interior/exterior designs, raw materials (cement, steel, etc.), and color combinations. Provide helpful, practical, and culturally relevant advice. User query: ${userMessage}` }]
          }
        ],
        config: {
          systemInstruction: "You are VastuPlan AI, a helpful assistant for construction planning, interior/exterior design, and material selection with an Indian context."
        }
      });

      const botResponse = response.text || "I apologize, but I'm having trouble processing that request right now. Could you try rephrasing it?";
      setMessages(prev => [...prev, { role: 'bot', text: botResponse }]);
    } catch (error) {
      console.error('Gemini Error:', error);
      setMessages(prev => [...prev, { role: 'bot', text: 'Sorry, I encountered an error. Please check your connection and try again.' }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto h-[calc(100vh-12rem)] flex flex-col bg-white/90 backdrop-blur-md rounded-3xl shadow-2xl border border-[#D2B48C] overflow-hidden">
      {/* Header */}
      <div className="p-6 bg-[#8B4513] text-white flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-md">
            <Bot size={28} />
          </div>
          <div>
            <h2 className="text-xl font-bold">VastuPlan AI Assistant</h2>
            <p className="text-xs opacity-80 flex items-center gap-1"><Sparkles size={12} /> Expert Architect & Planner</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button className="p-2 hover:bg-white/10 rounded-xl transition-colors"><Mic size={20} /></button>
          <button className="p-2 hover:bg-white/10 rounded-xl transition-colors"><Volume2 size={20} /></button>
        </div>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 scroll-smooth">
        <AnimatePresence>
          {messages.map((msg, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: msg.role === 'user' ? 20 : -20 }}
              animate={{ opacity: 1, x: 0 }}
              className={`flex items-start gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
            >
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center shadow-md ${msg.role === 'user' ? 'bg-[#D2691E] text-white' : 'bg-[#F5DEB3] text-[#8B4513]'}`}>
                {msg.role === 'user' ? <User size={20} /> : <Bot size={20} />}
              </div>
              <div className={`max-w-[80%] p-4 rounded-2xl shadow-sm ${msg.role === 'user' ? 'bg-[#D2691E] text-white rounded-tr-none' : 'bg-[#FFF8DC] text-[#5D4037] rounded-tl-none border border-[#D2B48C]'}`}>
                <div className="prose prose-sm max-w-none prose-brown">
                  <ReactMarkdown>{msg.text}</ReactMarkdown>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        {loading && (
          <div className="flex items-center gap-2 text-[#8B4513] font-bold animate-pulse">
            <Loader2 className="animate-spin" size={20} /> AI is thinking...
          </div>
        )}
      </div>

      {/* Input */}
      <div className="p-6 border-t border-[#D2B48C] bg-white/50">
        <div className="flex gap-4">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask about materials, Vastu, or design ideas..."
            className="flex-1 p-4 bg-white rounded-2xl border border-[#D2B48C] focus:ring-2 focus:ring-[#8B4513] focus:border-transparent outline-none shadow-inner transition-all"
          />
          <button
            onClick={handleSend}
            disabled={loading}
            className="bg-[#8B4513] text-white p-4 rounded-2xl shadow-lg hover:bg-[#5D4037] disabled:opacity-50 transition-all flex items-center justify-center"
          >
            <Send size={24} />
          </button>
        </div>
      </div>
    </div>
  );
}
